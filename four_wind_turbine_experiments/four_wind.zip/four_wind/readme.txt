first stage model:
previous name: first_stage_model_PR_exp1B
current name: first_stage_model
Based on a setup that:
 - removed energy rating and left it as 5 times power rating first stage
 - had a budget of 3500 in model numbers which is essentially arbitrary.
 - This was referred to as "experiment 1B"

second stage model (old):
previous name: PR_exp3_scen_1
current name: old_second_stage_model_scen_1
Based on a setup that:
 - removed energy rating and left it as 5 times power rating first stage
 - made traditional generators > 100MW ramping rate 45% of capacity (called Experiment 3)
 - only had one wind generator at bus 122.

second stage model (new):
current name: second_stage_model_scen_1
 - same as old except there are wind generators at buses 103, 109, and 117, as well as 122.